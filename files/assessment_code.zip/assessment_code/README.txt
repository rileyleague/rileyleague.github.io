The file assessmentofspending.do contains the Stata code used to perform the analyses presented in League et al. (2022).
The code uses the HCCI 2.0 dataset, access to which can be applied for at healthcostinstitute.org.
To run, the code needs to be altered to include the correct NORC data enclave username and password as well as the file paths where the output should go.
The code exports six files: totalspending_sumstats_estsamp.tex, totalspending_sumstats_keepmissing.tex, event_studies.csv, unadjusted_diff.tex, adjusted_diff.tex, and histogram.xlsx.
totalspending_sumstats_estsamp.tex underlies Table 1 in the paper.
totalspending_sumstats_keepmissing.tex underlies the eTable presented in the supplement.
event_studies.csv underlies Figure 1 in the paper.
unadjusted_diff.tex and adjusted_diff.tex underly Table 2 in the paper.
histogram.xlsx underlies Figures 2 and 3 in the paper.

League RJ, Eliason P, McDevitt RC, Roberts JW, Wong H. Assessment of spending for patients initiating dialysis care. JAMA Netw Open. 2022;5(10):e2239131. doi:10.1001/jamanetworkopen.2022.39131