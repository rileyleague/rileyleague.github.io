The file variabilityofprices.do contains the Stata code used to perform the analyses presented in League et al. (2022).
The code uses the HCCI 2.0 dataset, access to which can be applied for at healthcostinstitute.org.
To run, the code needs to be altered to include the correct NORC data enclave username and password as well as the file paths where the output should go.
The code exports three files: timeseries.pdf, timeseries.xlsx, and statelevel.xlsx.
timeseries.pdf and timeseries.xlsx underly the Figure presented in the paper.
statelevel.xlsx underlies the Table presented in the paper.

League RJ, Eliason P, McDevitt RC, Roberts JW, Wong H. Variability of prices paid for hemodialysis by employer-sponsored insurance in the US, 2012 to 2019. JAMA Netw Open. 2022;5(2):e220562. doi:10.1001/jamanetworkopen.2022.0562.